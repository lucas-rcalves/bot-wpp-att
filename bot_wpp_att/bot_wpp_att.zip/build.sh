#!/bin/bash

zip -r "bot_wpp_att.zip" * -x "bot_wpp_att.zip"